import React,{FC, useState,useEffect} from 'react';

import styles from './QuestionCheckbox.module.scss';

type PropsType={
  fe_id:string,
  props:{
    title:string,
    isVertical?:boolean,
    list:Array<{
      value:string,
      text:string,
      checked:boolean,
    }>
  }
}

const QuestionCheckbox: FC<PropsType> = ({fe_id,props}) => {
  const {title,isVertical,list=[]} = props;

  const [selectedValues, setSelectedValues]=useState<string[]>([])

  //初始化时，根据checked设置选中项
  useEffect(()=>{
    list.forEach((item)=>{
      const{value,checked} = item
      if(checked){
        setSelectedValues(selectedValues.concat(value))
      }
    })
  },[list])

  //切换选中项
  function toggleChecked(value:string){
    if(selectedValues.includes(value)){
      //如果已选中，取消选中
      setSelectedValues(selectedValues.filter((v)=>v!==value))
    }else{
      //如果未选中，选中
      setSelectedValues(selectedValues.concat(value))
    }
  }

  return <>
    <p>{title}</p>
    {/* 建一个隐藏的input，用于提交选中项 */}
    <input type="hidden" name={fe_id} value={selectedValues.toString()}  />

    <ul className={styles.list}>
      {list.map((item)=>{
        const {value,text,checked} = item

        //根据isVertical判断是垂直布局还是水平布局
        let className
        if(isVertical) className=styles.verticalItem
        else className=styles.horizontalItem

        return <li key={value} className={className}>
          <label>
            <input type="checkbox" 
              checked={selectedValues.includes(value)}
              onChange={()=>{toggleChecked(value)}}
            />
            {text}
          </label>
        </li>
      })}
    </ul>
  </>
}
export default QuestionCheckbox; 
